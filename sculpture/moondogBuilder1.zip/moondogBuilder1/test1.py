import numpy as np
from mathutils import Vector, Matrix
import bpy, bmesh
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import FloatProperty, PointerProperty, EnumProperty



###DEFINE USEFUL FUNCTIONS###

def meanCols(mat):
    '''calculates the mean of each column in a mathutils matrix and returns a row vector of means
    INPUTS:
        mat: a mathutils Matrix object
    RETURNS:
        means: a mathutils Vector containing the mean of each column in mat'''
    
    means = Vector([sum(col) / len(col) for col in mat.col])

    return means

def rotMat(rX, rY, rZ, order):
    '''builds a rotation matrix given rotations about x, y and z
    INPUTS:
        rX, rY, rZ: rotation angles about each axis in degrees
        order: order in which rotations should be applied, as a 3-element list of indices
            e.g. [0, 1, 2] for x>y>z, [2, 1, 0] for z>x>y
    RETURNS:
        R: 3x3 rotation matrix'''
    
    [rX, rY, rZ] = np.deg2rad([rX, rY, rZ]);

    RX = Matrix([[1, 0, 0],
        [0, np.cos(rX), -np.sin(rX)],
        [0, np.sin(rX), np.cos(rX)]])

    RY = Matrix([[np.cos(rY), 0, np.sin(rY)],
        [0, 1, 0],
        [-np.sin(rY), 0, np.cos(rY)]])
    
    RZ = Matrix([[np.cos(rZ), -np.sin(rZ), 0],
        [np.sin(rZ), np.cos(rZ), 0],
        [0, 0, 1]])
    
    Rs = [RX, RY, RZ]

    #rearrange individual components into the called-for order
    RsOrdered = [0, 0, 0]
    for i in range(3):
        RsOrdered[i] = Rs[order[i]]

    #matrix multiplication to form compound rotation matrix
    R = RsOrdered[0] @ RsOrdered[1] @ RsOrdered[2]

    return R

def calcTransMat(rot, centroid, trans):
    '''builds a 4x4 homographic transformation matrix to move a shape at the origin to meet a specific face of
    another shape. 
    INPUTS:
        rot: rotation matrix, pre-calculated and hardcoded for each face index
        centroid: of the face on which the shape is being placed, pre-calculated
        trans: world-space transformation matrix of the shape on which we're placing the new shape
    RETURNS:
        transMat: 4x4 mathutils Matrix'''

    transMat1 = rot.to_4x4() #expand 3x3 rotation matrix to 4x4
    transMat1[0][3] = centroid[0] #fill last column with translation vector
    transMat1[1][3] = centroid[1]
    transMat1[2][3] = centroid[2]

    #compound the transformation relative to target origin 
    #with the target's existing transformation relative to world origin
    transMat = trans @ transMat1 

    print("transformation matrix:", transMat)

    return transMat

def findFace(context):
    '''identifies the selected face of a shape, and the transformation matrix of that shape
    RETURNS:
        faceIndex: integer index of the selected face
        trans: 4x4 homographic transformation matrix of the object to which the face belongs'''
    
    obj = context.edit_object #the object which is being edited now
    name = obj.name_full

    bm = bmesh.from_edit_mesh(obj.data)
    selectFace = []
    for f in range(len(bm.faces)):
        if bm.faces[f].select: 
            selectFace.append(f)

    if name.startswith("tetrahedron"):
        faceIndex = selectFace[0] + 2 #tetrahedron faces occupy indices 2-5 in the lists
    elif name.startswith("octahedron"):
        if selectFace[0] < 2: #only faces 0 and 1 of octahedron are valid
            faceIndex = selectFace[0]

    trans = obj.matrix_world

    return faceIndex, trans

def placeObj(objName, transMat):
    '''places a copy of an object at a specified location, links it to the same collection
    as the original object
    INPUTS:
        objName: the name of the object to be copied
        transMat: the transformation matrix to apply to the copy'''
    
    #create new object
    obj = bpy.data.objects[objName]
    newObj = obj.copy()
    
    #link to same collection
    coll = obj.users_collection[0]
    coll.objects.link(newObj)

    #transform new object
    newObj.matrix_world = transMat


###ENCODE SHAPE PROPERTIES###

#coordinates of the vertices of each shape 
#the octahedron
O1 = Vector([0, 1, 0])
O2 = Vector([-np.sqrt(3) / 2, -1/2, 0])
O3 = Vector([np.sqrt(3) / 2, -1/2, 0])
O4 = Vector([0, -1, 2*np.sqrt(2)])
O5 = Vector([np.sqrt(3) / 2, 1/2, 2*np.sqrt(2)])
O6 = Vector([-np.sqrt(3) / 2, 1/2, 2*np.sqrt(2)])

#the tetrahedron
T1 = O1
T2 = O2
T3 = O3
T4 = np.array([0, 0, np.sqrt(2)])


#matrices representing the faces of each shape which may be joined
Oface1 = Matrix([O1, O2, O3])
Oface2 = Matrix([O4, O5, O6])

Tface1 = Matrix([T1, T2, T3])
Tface2 = Matrix([T1, T2, T4])
Tface3 = Matrix([T4, T2, T3])
Tface4 = Matrix([T1, T3, T4])


#coordinates of centroids of each face
Ocent1 = meanCols(Oface1)
Ocent2 = meanCols(Oface2)

Tcent1 = meanCols(Tface1)
Tcent2 = meanCols(Tface2)
Tcent3 = meanCols(Tface3)
Tcent4 = meanCols(Tface4)

#put all centroids into a list for easy lookup
centroids = [Ocent1, Ocent2, Tcent1, Tcent2, Tcent3, Tcent4]

#begin building transformation matrices for each case of placing one face on another

#placing on bottom of O OR bottom of T
OT1R = rotMat(180, 0, 60, [0, 1, 2])

#placing on top of O
O2R = rotMat(0, 0, 180, [0, 1, 2])

a = np.rad2deg(np.acos(1/3)) #angle by which to rotate to align with upper faces of T

#placing on upper faces of T
T2R = rotMat(a, 0, -120, [2, 1, 0])
T3R = rotMat(a, 0, 0, [2, 1, 0])
T4R = rotMat(a, 0, 120, [2, 1, 0])

#rotation matrices in a list, indices match centroids
rotMats = [OT1R, O2R, OT1R, T2R, T3R, T4R]



###CREATE OPERATORS FOR PLACING SHAPES###

class placeOcta(Operator): #create an operator; important: name must be unique from functions, property groups, etc.
    bl_idname = "collection.placeocta" #attach the operator to a portion of the blender data and give it an idname (must be all lowercase)
    bl_label = "Place Octahedron On Face"
    
    bl_options = {"REGISTER", "UNDO"} #Make it undoable
    
    def execute(self, context): #execute method (needed for operator to do things)
        
        faceIndex, trans = findFace(context)
        transMat = calcTransMat(rotMats[faceIndex], centroids[faceIndex], trans)
        placeObj("octahedron.001", transMat)
    
        return{"FINISHED"} #needed
    

class placeTetra(Operator): #create an operator; important: name must be unique from functions, property groups, etc.
    bl_idname = "collection.placetetra" #attach the operator to a portion of the blender data and give it an idname (must be all lowercase)
    bl_label = "Place tetrahedron On Face"
    
    bl_options = {"REGISTER", "UNDO"} #Make it undoable
    
    def execute(self, context): #execute method (needed for operator to do things)
        
        faceIndex, trans = findFace(context)
        transMat = calcTransMat(rotMats[faceIndex], centroids[faceIndex], trans)
        placeObj("tetrahedron.001", transMat)
    
        return{"FINISHED"} #needed
    
bpy.utils.register_class(placeOcta) #register the operator (has to be done before drawing it into GUI)
bpy.utils.register_class(placeTetra)

class panelName(bpy.types.Panel): #create a panel in the GUI
    bl_label = "Moondog Builder"
    bl_idname = "moondogbuilder"
    bl_space_type = "VIEW_3D" #e.g. puts it in the 3D viewport
    bl_region_type = "UI" #e.g. puts it in the N-menu
    bl_category = "Ramsdell Tools" #e.g. puts it in a new tab called this
    
    def draw(self, context): #draw method (needed)
        layout = self.layout
        
        #draw-in controls for properties and a button to execute the operator
        layout.operator("collection.placeocta")
        layout.operator("collection.placetetra")
        
bpy.utils.register_class(panelName) #register the panel

