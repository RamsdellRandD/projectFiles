import numpy as np
from mathutils import Vector, Matrix
import bpy, bmesh
from bpy.types import Panel, Operator, PropertyGroup



###DEFINE USEFUL FUNCTIONS###

def meanCols(mat):
    '''calculates the mean of each column in a mathutils matrix and returns a row vector of means
    INPUTS:
        mat: a mathutils Matrix object
    RETURNS:
        means: a mathutils Vector containing the mean of each column in mat'''
    
    means = Vector([sum(col) / len(col) for col in mat.col])

    return means

def rotMat(rX, rY, rZ, order):
    '''builds a rotation matrix given rotations about x, y and z
    INPUTS:
        rX, rY, rZ: rotation angles about each axis in degrees
        order: order in which rotations should be applied, as a 3-element list of indices
            e.g. [0, 1, 2] for x>y>z, [2, 1, 0] for z>x>y
    RETURNS:
        R: 3x3 rotation matrix'''
    
    [rX, rY, rZ] = np.deg2rad([rX, rY, rZ]);

    RX = Matrix([[1, 0, 0],
        [0, np.cos(rX), -np.sin(rX)],
        [0, np.sin(rX), np.cos(rX)]])

    RY = Matrix([[np.cos(rY), 0, np.sin(rY)],
        [0, 1, 0],
        [-np.sin(rY), 0, np.cos(rY)]])
    
    RZ = Matrix([[np.cos(rZ), -np.sin(rZ), 0],
        [np.sin(rZ), np.cos(rZ), 0],
        [0, 0, 1]])
    
    Rs = [RX, RY, RZ]

    #rearrange individual components into the called-for order
    RsOrdered = [0, 0, 0]
    for i in range(3):
        RsOrdered[i] = Rs[order[i]]

    #matrix multiplication to form compound rotation matrix
    R = RsOrdered[0] @ RsOrdered[1] @ RsOrdered[2]

    return R

def calcTransMat(rot, centroid, trans):
    '''builds a 4x4 homographic transformation matrix to move a shape at the origin to meet a specific face of
    another shape. 
    INPUTS:
        rot: rotation matrix, pre-calculated and hardcoded for each face index
        centroid: of the face on which the shape is being placed, pre-calculated
        trans: world-space transformation matrix of the shape on which we're placing the new shape
    RETURNS:
        transMat: 4x4 mathutils Matrix'''

    transMat1 = rot.to_4x4() #expand 3x3 rotation matrix to 4x4
    transMat1[0][3] = centroid[0] #fill last column with translation vector
    transMat1[1][3] = centroid[1]
    transMat1[2][3] = centroid[2]

    #compound the transformation relative to target origin 
    #with the target's existing transformation relative to world origin
    transMat = trans @ transMat1 

    # print("transformation matrix:", transMat)

    return transMat

def findFace(context):
    '''identifies the selected face of a shape, and the transformation matrix of that shape
    RETURNS:
        faceIndex: integer index of the selected face
        trans: 4x4 homographic transformation matrix of the object to which the face belongs'''
    
    obj = context.edit_object #the object which is being edited now
    print(obj)
    name = obj.name_full

    bm = bmesh.from_edit_mesh(obj.data)
    selectFace = []
    for f in range(len(bm.faces)):
        if bm.faces[f].select: 
            selectFace.append(f)

    if name.startswith("tetrahedron"):
        faceIndex = selectFace[0] + 2 #tetrahedron faces occupy indices 2-5 in the lists
    elif name.startswith("octahedron"):
        if selectFace[0] < 2: #only faces 0 and 1 of octahedron are valid
            faceIndex = selectFace[0]

    trans = obj.matrix_world

    return faceIndex, trans

def placeObj(objName, transMat):
    '''places a copy of an object at a specified location, links it to the same collection
    as the original object
    INPUTS:
        objName: the name of the object to be copied
        transMat: the transformation matrix to apply to the copy'''
    
    #create new object
    obj = bpy.data.objects[objName]
    newObj = obj.copy()
    
    #link to same collection
    coll = obj.users_collection[0]
    coll.objects.link(newObj)

    #transform new object
    newObj.matrix_world = transMat