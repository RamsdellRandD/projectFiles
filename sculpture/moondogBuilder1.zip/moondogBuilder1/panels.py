import numpy as np
from mathutils import Vector, Matrix
import bpy, bmesh
from bpy.types import Panel, Operator, PropertyGroup
from .functions import findFace, calcTransMat, placeObj
from .constants import rotMats, centroids

class moondogPanel(bpy.types.Panel): #create a panel in the GUI
    bl_label = "Moondog Builder"
    bl_idname = "moondogbuilder"
    bl_space_type = "VIEW_3D" #e.g. puts it in the 3D viewport
    bl_region_type = "UI" #e.g. puts it in the N-menu
    bl_category = "Ramsdell Tools" #e.g. puts it in a new tab called this
    
    def draw(self, context): #draw method (needed)
        layout = self.layout
        
        #draw-in controls for properties and a button to execute the operator
        layout.operator("collection.placeocta")
        layout.operator("collection.placetetra")