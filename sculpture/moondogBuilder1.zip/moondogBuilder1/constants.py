import bpy
from mathutils import Matrix, Vector
import numpy as np
from .functions import meanCols, rotMat

###ENCODE SHAPE PROPERTIES###

#coordinates of the vertices of each shape 
#the octahedron
O1 = Vector([0, 1, 0])
O2 = Vector([-np.sqrt(3) / 2, -1/2, 0])
O3 = Vector([np.sqrt(3) / 2, -1/2, 0])
O4 = Vector([0, -1, 2*np.sqrt(2)])
O5 = Vector([np.sqrt(3) / 2, 1/2, 2*np.sqrt(2)])
O6 = Vector([-np.sqrt(3) / 2, 1/2, 2*np.sqrt(2)])

#the tetrahedron
T1 = O1
T2 = O2
T3 = O3
T4 = np.array([0, 0, np.sqrt(2)])


#matrices representing the faces of each shape which may be joined
Oface1 = Matrix([O1, O2, O3])
Oface2 = Matrix([O4, O5, O6])

Tface1 = Matrix([T1, T2, T3])
Tface2 = Matrix([T1, T2, T4])
Tface3 = Matrix([T4, T2, T3])
Tface4 = Matrix([T1, T3, T4])


#coordinates of centroids of each face
Ocent1 = meanCols(Oface1)
Ocent2 = meanCols(Oface2)

Tcent1 = meanCols(Tface1)
Tcent2 = meanCols(Tface2)
Tcent3 = meanCols(Tface3)
Tcent4 = meanCols(Tface4)

#put all centroids into a list for easy lookup
centroids = [Ocent1, Ocent2, Tcent1, Tcent2, Tcent3, Tcent4]

#begin building transformation matrices for each case of placing one face on another

#placing on bottom of O OR bottom of T
OT1R = rotMat(180, 0, 60, [0, 1, 2])

#placing on top of O
O2R = rotMat(0, 0, 180, [0, 1, 2])

a = np.rad2deg(np.acos(1/3)) #angle by which to rotate to align with upper faces of T

#placing on upper faces of T
T2R = rotMat(a, 0, -120, [2, 1, 0])
T3R = rotMat(a, 0, 0, [2, 1, 0])
T4R = rotMat(a, 0, 120, [2, 1, 0])

#rotation matrices in a list, indices match centroids
rotMats = [OT1R, O2R, OT1R, T2R, T3R, T4R]



