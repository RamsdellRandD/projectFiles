import numpy as np
from mathutils import Vector, Matrix
import bpy, bmesh
from bpy.types import Panel, Operator, PropertyGroup
from .functions import findFace, calcTransMat, placeObj
from .constants import rotMats, centroids

class placeOcta(Operator): #create an operator; important: name must be unique from functions, property groups, etc.
    bl_idname = "collection.placeocta" #attach the operator to a portion of the blender data and give it an idname (must be all lowercase)
    bl_label = "Place Octahedron On Face"
    
    bl_options = {"REGISTER", "UNDO"} #Make it undoable
    
    def execute(self, context): #execute method (needed for operator to do things)
        
        faceIndex, trans = findFace(context)
        transMat = calcTransMat(rotMats[faceIndex], centroids[faceIndex], trans)
        placeObj("octahedron.001", transMat)
    
        return{"FINISHED"} #needed
    

class placeTetra(Operator): #create an operator; important: name must be unique from functions, property groups, etc.
    bl_idname = "collection.placetetra" #attach the operator to a portion of the blender data and give it an idname (must be all lowercase)
    bl_label = "Place tetrahedron On Face"
    
    bl_options = {"REGISTER", "UNDO"} #Make it undoable
    
    def execute(self, context): #execute method (needed for operator to do things)
        
        faceIndex, trans = findFace(context)
        transMat = calcTransMat(rotMats[faceIndex], centroids[faceIndex], trans)
        placeObj("tetrahedron.001", transMat)
    
        return{"FINISHED"} #needed